import { Button,Table,Modal,Form} from 'antd'
import React,{ useState } from 'react'
import 'antd/dist/antd.min.css';
import style from './User.module.css';
import Input from 'antd/lib/input/Input';
import DeleteUser from './DeleteUser';
const User = () => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const handleDelete=()=>{

  }
    const dataSource = [
        {
          key: '1',
          name: 'Mike',
          email: 'tes@tes.com',
          mobile: '1234567899',
        },
      ];
      const columns = [
        {
          title: 'Name',
          dataIndex: 'name',
          key: 'name',
        },
        {
          title: 'Email',
          dataIndex: 'email',
          key: 'email',
        },
        {
          title: 'Mobile',
          dataIndex: 'mobile',
          key: 'mobile',
        },
          {
            key: "5",
            title: "Actions",
            render: (record) => {
              return (
                <>
                <div className={style.Btn__cls}>
                  <Button type="primary"> edit</Button>
                  <Button type="primary" onClick={handleDelete}>delete</Button>
                  </div>
                </>
              );
            },
          },
      ];
      const showModal = () => {
        setIsAddModalOpen(true);
      };
    
      const handleOk = () => {
        setIsAddModalOpen(false);
      };
    
      const handleCancel = () => {
        setIsAddModalOpen(false);
      };
  return (
    <div >
        <Button type="primary" onClick={showModal}>Add New User</Button>
        <Table dataSource={dataSource} columns={columns} />;
        <Modal title="Add User" open={isAddModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <Form className="add-edit-form-css"
        name="basic"
        labelCol={{
          span: 8,
        }}
        wrapperCol={{
          span: 16,
        }}
        autoComplete="off"
        // initialValues={{
        //   name: props.formFor === "add" ? "" : props.dataSource.name,
        //   email: props.formFor === "add" ? "" : props.dataSource.email,
        //   address: props.formFor === "add" ? "" : props.dataSource.address,
        // }}
      >
        <Form.Item
          label="Name"
          name="name"
          rules={[
            {
              required: true,
              message: "Please input your name!",
            },
          ]}
        >
          <Input allowClear className="input-css" placeholder="Name" />
        </Form.Item>

        <Form.Item
          label="Email"
          type="email"
          name="email"
          rules={[
            {
              type: "email",
              message: "The input is not valid E-mail!",
            },
            {
              required: true,
              message: "Please input your E-mail!",
            },
          ]}
        >
          <Input Input allowClear className="input-css" placeholder="Email" />
        </Form.Item>
        <Form.Item
          label="Mobile"
          name="mobile"
          rules={[
            {
              required: true,
              message: "Please input your phone number!",
            },
            {
              max: 10,
              message: "Maximum length should be 10",
            },
          ]}
        >
          <Input type='number' Input allowClear  placeholder="mobile number" />
        </Form.Item>
      </Form>
      </Modal>
    </div>
  )
}

export default User